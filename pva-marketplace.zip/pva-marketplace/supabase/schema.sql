-- PVA Marketplace database schema
-- Run this once in Supabase Dashboard -> SQL Editor -> New query -> Run.

-- ============ PROFILES (one per logged-in user) ============
create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  name text not null,
  email text not null,
  portfolio text default '',
  note text default '',
  -- 'buyer' = signed in, never applied to sell. 'pending' = seller application
  -- submitted, awaiting admin review. 'approved' = can post services.
  status text not null default 'buyer' check (status in ('buyer','pending','approved','rejected')),
  is_admin boolean not null default false,
  -- Payout details, used when we send this seller their share of a sale
  payout_channel text default '',       -- e.g. 'PH_GCASH', 'PH_MAYA', 'PH_BDO', 'PH_BPI'
  payout_account_number text default '',
  payout_account_name text default '',
  created_at timestamptz not null default now()
);

alter table profiles enable row level security;

create policy "profiles are viewable by everyone"
  on profiles for select using (true);

create policy "users can insert their own profile"
  on profiles for insert with check (auth.uid() = id);

create policy "users can update their own profile"
  on profiles for update using (auth.uid() = id);

-- ============ SERVICES (listings) ============
create table if not exists services (
  id uuid primary key default gen_random_uuid(),
  seller_id uuid not null references profiles(id) on delete cascade,
  seller_name text not null,
  category text not null,
  title text not null,
  description text not null,
  rate numeric not null,
  delivery text not null,
  tz text not null,
  rating numeric not null default 5.0,
  reviews int not null default 0,
  created_at timestamptz not null default now()
);

alter table services enable row level security;

create policy "services are viewable by everyone"
  on services for select using (true);

create policy "approved sellers can insert their own services"
  on services for insert with check (
    auth.uid() = seller_id
    and exists (select 1 from profiles p where p.id = auth.uid() and p.status = 'approved')
  );

create policy "sellers can update their own services"
  on services for update using (auth.uid() = seller_id);

-- ============ ORDERS (an inquiry that can turn into a paid job) ============
create table if not exists orders (
  id uuid primary key default gen_random_uuid(),
  service_id uuid not null references services(id) on delete cascade,
  service_title text not null,
  seller_id uuid not null references profiles(id),
  seller_name text not null,
  buyer_id uuid not null references profiles(id),
  buyer_name text not null,
  contact text not null,
  message text not null,
  amount numeric,                 -- agreed price in PHP, set when buyer is ready to pay
  status text not null default 'sent' check (
    status in ('sent','replied','invoiced','paid','completed','cancelled')
  ),
  xendit_invoice_id text,
  xendit_invoice_url text,
  platform_fee_percent numeric not null default 10,
  created_at timestamptz not null default now()
);

alter table orders enable row level security;

create policy "buyer or seller can view their own orders"
  on orders for select using (auth.uid() = buyer_id or auth.uid() = seller_id);

create policy "buyer can create an order"
  on orders for insert with check (auth.uid() = buyer_id);

create policy "buyer or seller can update their own orders"
  on orders for update using (auth.uid() = buyer_id or auth.uid() = seller_id);

-- ============ MESSAGES (chat thread attached to an order) ============
create table if not exists messages (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references orders(id) on delete cascade,
  sender_id uuid not null references profiles(id),
  body text not null,
  created_at timestamptz not null default now()
);

alter table messages enable row level security;

create policy "buyer or seller on the order can read messages"
  on messages for select using (
    exists (
      select 1 from orders o
      where o.id = messages.order_id
      and (o.buyer_id = auth.uid() or o.seller_id = auth.uid())
    )
  );

create policy "buyer or seller on the order can send messages"
  on messages for insert with check (
    auth.uid() = sender_id
    and exists (
      select 1 from orders o
      where o.id = messages.order_id
      and (o.buyer_id = auth.uid() or o.seller_id = auth.uid())
    )
  );

-- Realtime: let the client subscribe to new chat messages live
alter publication supabase_realtime add table messages;
alter publication supabase_realtime add table orders;

-- To make yourself an admin after signing up once, run:
-- update profiles set is_admin = true where email = 'you@example.com';
