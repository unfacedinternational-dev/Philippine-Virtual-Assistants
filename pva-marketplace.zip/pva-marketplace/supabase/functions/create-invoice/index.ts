// Supabase Edge Function: create-invoice
// Called by the app when a buyer clicks "Pay now" on an order.
// Talks to Xendit with the SECRET key, which must never reach the browser —
// that's the whole reason this runs on the server instead of in App.jsx.
//
// Deploy with:
//   supabase functions deploy create-invoice
// Set secrets once with:
//   supabase secrets set XENDIT_SECRET_KEY=xnd_development_xxx
//   supabase secrets set SUPABASE_SERVICE_ROLE_KEY=xxx  (from Project Settings -> API)

import { createClient } from 'jsr:@supabase/supabase-js@2';

const XENDIT_SECRET_KEY = Deno.env.get('XENDIT_SECRET_KEY')!;
const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!;
const SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;

Deno.serve(async (req) => {
  if (req.method !== 'POST') {
    return new Response('Method not allowed', { status: 405 });
  }

  try {
    const { order_id, amount } = await req.json();
    if (!order_id || !amount || amount <= 0) {
      return new Response(JSON.stringify({ error: 'order_id and a positive amount are required' }), { status: 400 });
    }

    // Verify the caller is actually the buyer on this order before charging anyone.
    const authHeader = req.headers.get('Authorization') ?? '';
    const supabase = createClient(SUPABASE_URL, SERVICE_ROLE_KEY);
    const userClient = createClient(SUPABASE_URL, SERVICE_ROLE_KEY, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: userData, error: userErr } = await userClient.auth.getUser();
    if (userErr || !userData?.user) {
      return new Response(JSON.stringify({ error: 'Not signed in' }), { status: 401 });
    }

    const { data: order, error: orderErr } = await supabase
      .from('orders')
      .select('*')
      .eq('id', order_id)
      .single();
    if (orderErr || !order) {
      return new Response(JSON.stringify({ error: 'Order not found' }), { status: 404 });
    }
    if (order.buyer_id !== userData.user.id) {
      return new Response(JSON.stringify({ error: 'Only the buyer on this order can pay for it' }), { status: 403 });
    }

    const externalId = `order_${order_id}_${Date.now()}`;

    const xenditRes = await fetch('https://api.xendit.co/v2/invoices', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        // Xendit auth: HTTP Basic with secret key as username, empty password
        Authorization: 'Basic ' + btoa(`${XENDIT_SECRET_KEY}:`),
      },
      body: JSON.stringify({
        external_id: externalId,
        amount,
        currency: 'PHP',
        description: `Payment for: ${order.service_title}`,
        invoice_duration: 86400, // 24 hours to pay
      }),
    });

    const invoice = await xenditRes.json();
    if (!xenditRes.ok) {
      return new Response(JSON.stringify({ error: 'Xendit error', details: invoice }), { status: 502 });
    }

    await supabase
      .from('orders')
      .update({
        amount,
        status: 'invoiced',
        xendit_invoice_id: invoice.id,
        xendit_invoice_url: invoice.invoice_url,
      })
      .eq('id', order_id);

    return new Response(JSON.stringify({ invoice_url: invoice.invoice_url }), {
      headers: { 'Content-Type': 'application/json' },
    });
  } catch (e) {
    return new Response(JSON.stringify({ error: String(e) }), { status: 500 });
  }
});
