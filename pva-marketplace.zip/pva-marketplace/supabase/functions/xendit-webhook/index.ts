// Supabase Edge Function: xendit-webhook
// Set this URL as your "Invoice Paid" webhook in the Xendit Dashboard:
//   Settings -> Webhooks -> Invoices Paid
//   URL: https://<your-project-ref>.supabase.co/functions/v1/xendit-webhook
//
// Xendit sends a "x-callback-token" header — set XENDIT_WEBHOOK_TOKEN to the
// verification token shown on that same Webhooks page, so random requests
// can't fake a "paid" event and trigger a payout.
//
//   supabase secrets set XENDIT_WEBHOOK_TOKEN=xxx
//   supabase secrets set XENDIT_SECRET_KEY=xnd_development_xxx
//   supabase secrets set SUPABASE_SERVICE_ROLE_KEY=xxx

import { createClient } from 'jsr:@supabase/supabase-js@2';

const XENDIT_SECRET_KEY = Deno.env.get('XENDIT_SECRET_KEY')!;
const XENDIT_WEBHOOK_TOKEN = Deno.env.get('XENDIT_WEBHOOK_TOKEN')!;
const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!;
const SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;

Deno.serve(async (req) => {
  const token = req.headers.get('x-callback-token');
  if (token !== XENDIT_WEBHOOK_TOKEN) {
    return new Response('Invalid webhook token', { status: 401 });
  }

  const payload = await req.json();
  if (payload.status !== 'PAID' && payload.status !== 'SETTLED') {
    // Ignore EXPIRED / PENDING notifications for this simple flow.
    return new Response('ok', { status: 200 });
  }

  const supabase = createClient(SUPABASE_URL, SERVICE_ROLE_KEY);

  const { data: order, error: orderErr } = await supabase
    .from('orders')
    .select('*, seller:seller_id(*)')
    .eq('xendit_invoice_id', payload.id)
    .single();

  if (orderErr || !order) {
    return new Response('Order not found for this invoice', { status: 404 });
  }
  if (order.status === 'paid' || order.status === 'completed') {
    return new Response('Already processed', { status: 200 }); // avoid double payouts on retries
  }

  await supabase.from('orders').update({ status: 'paid' }).eq('id', order.id);

  const seller = order.seller;
  const feePercent = order.platform_fee_percent ?? 10;
  const payoutAmount = Math.floor(order.amount * (1 - feePercent / 100));

  if (!seller?.payout_channel || !seller?.payout_account_number) {
    // Seller hasn't filled in payout details yet — money stays in the
    // platform's Xendit balance until you disburse manually from the dashboard.
    return new Response('Paid, but seller has no payout details on file yet', { status: 200 });
  }

  // Send the seller their share. Xendit Payouts API — confirm current
  // channel_code values (PH_GCASH, PH_MAYA, PH_BDO, PH_BPI, etc.) against
  // your Xendit Dashboard before going live; these are renamed occasionally.
  const payoutRes = await fetch('https://api.xendit.co/v2/payouts', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: 'Basic ' + btoa(`${XENDIT_SECRET_KEY}:`),
      'Idempotency-key': `payout_${order.id}`,
    },
    body: JSON.stringify({
      reference_id: `payout_${order.id}`,
      channel_code: seller.payout_channel,
      channel_properties: {
        account_holder_name: seller.payout_account_name,
        account_number: seller.payout_account_number,
      },
      amount: payoutAmount,
      currency: 'PHP',
      description: `Payout for order ${order.id}`,
    }),
  });

  const payout = await payoutRes.json();
  if (!payoutRes.ok) {
    // Payment is safely recorded as paid either way — payout can be retried
    // manually. Log details so you can see what went wrong.
    console.error('Xendit payout failed', payout);
    return new Response('Paid, payout failed — check function logs', { status: 200 });
  }

  await supabase.from('orders').update({ status: 'completed' }).eq('id', order.id);
  return new Response('ok', { status: 200 });
});
